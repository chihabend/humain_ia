import pandas as pd
from datasets import Dataset
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, TrainingArguments, Trainer

print("[LOG] Début du script d'entraînement.")

MODEL_NAME = "t5-small"
print(f"[LOG] Chargement du tokenizer et du modèle : {MODEL_NAME}")
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)

print("[LOG] Chargement du dataset CSV...")
df = pd.read_csv("data/humanization_pairs.csv")
print(f"[LOG] Dataset chargé : {len(df)} lignes.")
dataset = Dataset.from_pandas(df)

def preprocess(example):
    return tokenizer(
        example["input"],
        text_target=example["target"],
        truncation=True,
        padding="max_length",
        max_length=128
    )

print("[LOG] Prétraitement des données...")
tokenized = dataset.map(preprocess)
print("[LOG] Données tokenisées.")

args = TrainingArguments(
    output_dir="./humanizer_model",
    per_device_train_batch_size=8,
    num_train_epochs=3,
    save_steps=500,
    save_total_limit=2,
    logging_steps=100
)

print("[LOG] Initialisation du Trainer...")
trainer = Trainer(
    model=model,
    args=args,
    train_dataset=tokenized,
    tokenizer=tokenizer,
)

print("[LOG] Début de l'entraînement...")
trainer.train()
print("[LOG] Entraînement terminé. Sauvegarde du modèle...")
model.save_pretrained("./humanizer_model")
tokenizer.save_pretrained("./humanizer_model")
print("[LOG] Modèle et tokenizer sauvegardés dans ./humanizer_model.") 
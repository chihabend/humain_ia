Ce dossier contiendra les checkpoints du modèle entraîné.

Après l'entraînement, les fichiers de modèle seront sauvegardés ici automatiquement par le script d'entraînement.

Ne pas supprimer ce dossier si vous souhaitez conserver les modèles générés. 